/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadora;

import aritmetica.accion;
import aritmetica.operaciones;
import conversor.accionConvertir;
import conversor.tipConv;

/**
 *
 * @author LN710Q
 */
public interface abstractFactory {
    accion getAccion(operaciones type);
    accionConvertir getAccionConv(tipConv type);
}
