/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadora;

import aritmetica.accion;
import aritmetica.factoryAritmetica;
import conversor.accionConvertir;
import conversor.factoryConversor;

/**
 *
 * @author thesecond
 */
public class FactoryProducer {
    public static abstractFactory getFactory(String type){
        switch (type){
            case "aritmetica":
                return new factoryAritmetica();
                
            case "convertir2":
                return new factoryConversor();
                
        }
        return null;
    }
}
