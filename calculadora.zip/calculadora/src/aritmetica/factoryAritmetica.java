/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aritmetica;

import calculadora.abstractFactory;
import conversor.accionConvertir;
import conversor.tipConv;

/**
 *
 * @author LN710Q
 */
public class factoryAritmetica implements abstractFactory {
    
    @Override
    public accionConvertir getAccionConv(tipConv type){
        return null;
    }
    @Override
    public accion getAccion(operaciones type){
        switch(type){
            case sumar:
                return new sumar();
            case restar:
                return new restar();
            case multiplicar:
                return new multiplicar();
            case dividir:
                return new dividir();
        }
        return null;
    }   
}
