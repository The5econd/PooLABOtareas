/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import calculadora.FactoryProducer;
import aritmetica.accion;
import aritmetica.factoryAritmetica;
import conversor.factoryConversor;
import java.awt.Rectangle;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author thesecond
 */
/*public class ventana extends JPanel {
    public int WIDTH = 300, widthTF = 120, widthB = 80;
    public int HEIGHT =300, heightTF = 30, heightB = 30;
    public JTextField text1,text2;
    public JButton button;
    
    public ventana(){
        text1 = new JTextField();
        text1.setBounds(new Rectangle(100,40,widthTF,heightTF));
        text2 = new JTextField();
        text2.setBounds(new Rectangle(100,200,widthTF,heightTF));
        
        button = new JButton("copiar");
        button.setBounds(new Rectangle(120,115,widthB,heightB));
        
        text1.setEditable(true);
        text1.setEditable(false);
        
        button.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(action event argO){
                text2.setText(text1.getText());
            }
        });

        
    }
}*/

import Abstract.FactoryProducer;
import Aritmetica.Aritmetica;
import Aritmetica.FactoryAritmetica;
import Aritmetica.TiposAritmetica;
import Converter.Converter;
import Converter.FactoryConverter;
import Converter.TipoConversor;
import aritmetica.operaciones;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;


/**
 *
 * @author Ricardo Villeda
 */
public class ventana extends JFrame{
    private JTextField caja1, caja2;
    private JButton btnSuma;
    factoryAritmetica ARIT;
    factoryConversor CONV;
    public ventana(){
        super("Calculadora");
        initComponent();
    }
    private void initComponent() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        caja1 = new JTextField(" ");
        caja1.setBounds(130,10,100,30);
        caja2 = new JTextField(" ");
        caja2.setBounds(250,10,100,30);
        Container contenedor = getContentPane();
        contenedor.add(caja1);
        contenedor.add(caja2);

        setSize(500,500);
        
        btnSuma.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
                ARIT = (factoryAritmetica) FactoryProducer.getFactory("aritmetica").getAccion(operaciones.sumar);
                JOptionPane.showMessageDialog(rootPane,"El resultado es: "+ARIT.operar(Double.parseDouble(caja1.getText()),Double.parseDouble(caja2.getText())));
            }
        });
        
    }
}

