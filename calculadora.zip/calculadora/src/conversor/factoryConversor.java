/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conversor;

import calculadora.abstractFactory;
import aritmetica.accion;
import aritmetica.operaciones;

/**
 *
 * @author LN710Q
 */
public class factoryConversor implements abstractFactory{
    
    @Override
    public accion getAccion(operaciones type){
        return null;
    }
    
    @Override
    public accionConvertir getAccionConv(tipConv type){
        switch(type){
            case convertir:
                return new decimalAbinario();
        }
        return null;
    }
}
